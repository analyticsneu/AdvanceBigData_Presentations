package com.mongo.student;

import java.io.StringWriter;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import spark.Request;
import spark.Response;
import spark.Route;
import spark.Spark;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

import freemarker.template.Configuration;
import freemarker.template.SimpleHash;
import freemarker.template.Template;

/**
 * RestLite Demo
 *
 */
public class AppController 
{
	private Configuration config;
	private Template template;
	private DBCollection coll;	

    public static void main( String[] args )
    {
		
		try {
			AppController controller = new AppController();			
			controller.initialise();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    
	public AppController() throws UnknownHostException{
		Spark.setPort(4565);
		config = new Configuration();
		config.setClassForTemplateLoading(AppController.class, "/");
		coll = new MongoClient(new MongoClientURI("mongodb://localhost"))
		.getDB("mydb").getCollection("student");
		
	}

	private void initialise() throws Exception {
		initCatalogue("/", "catalogueTemplate.fmt");
		studentRoute("/student", "studentTemplate.fmt");
	}

	private void initCatalogue(String routePath, String templateName)
			throws Exception {

		template = config.getTemplate(templateName);
		final StringWriter writer = new StringWriter();

		Map<String, String> catalogueMap = new HashMap<String, String>();
		catalogueMap.put("get_path", "http://localhost/student");
		catalogueMap.put("post_path", "http://localhost/student/add");
		catalogueMap.put("put_path", "http://localhost/update/:student_id");
		catalogueMap.put("delete_path", "http://localhost/remove/:student_id");

		template.process(catalogueMap, writer);

		Spark.get(new Route(routePath) {
			@Override
			public Object handle(Request arg0, Response arg1) {
				return writer;
			}
		});
	}

	private void studentRoute(String routePath, final String templateName)
			throws Exception {
		template = config.getTemplate(templateName);

		Spark.get(new Route(routePath) {
			StringWriter writer;

			@Override
			public Object handle(Request arg0, Response arg1) {

				try {
					List students;
					DBCursor cursor = coll.find().sort(
							new BasicDBObject("id", 1));
					try {
						students = cursor.toArray();
					} finally {
						cursor.close();
					}

					SimpleHash hash = new SimpleHash();
					hash.put("students", students);
					writer = new StringWriter();
					template.process(hash, writer);
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				return writer;
			}

		});

	}

}